// displayPost.js

function displayPost(postData, type) {
    const combinedPostsDiv = document.getElementById("combinedPostsList");
    const postDiv = document.createElement("div");
    postDiv.classList.add("post");

    // Display username and visibility flag
    const usernameElement = document.createElement("div");
    usernameElement.classList.add("username");
    usernameElement.textContent = `${postData.DiverName} (${postData.Visibility})`; // Displaying username and visibility
    postDiv.appendChild(usernameElement);

    // Display time posted
    const timeElement = document.createElement("div");
    timeElement.classList.add("time");
    timeElement.textContent = formatTime(postData.Date); // Using Date field as the timestamp
    postDiv.appendChild(timeElement);

    // Display main text content
    const mainTextElement = document.createElement("div");
    mainTextElement.classList.add("main-text");
    mainTextElement.textContent = postData.MainTextContent;
    postDiv.appendChild(mainTextElement);

    // Additional information
    const additionalInfoDiv = document.createElement("div");
    additionalInfoDiv.classList.add("additional-info");
    additionalInfoDiv.innerHTML = `
        <p><strong>Observations:</strong> ${postData.Observations || '-'}</p>
        <p><strong>Incidents:</strong> ${postData.Incidents || '-'}</p>
        <p><strong>Diver Certifications:</strong> ${postData.DiverCertifications || '-'}</p>
        <p><strong>Dive Location:</strong> ${postData.DiveLocation || '-'}</p>
        <p><strong>Diver Buddies Name:</strong> ${postData.DiverBuddiesName || '-'}</p>
    `;
    postDiv.appendChild(additionalInfoDiv);

    // Display media content
    if (postData.ImageLinks && postData.ImageLinks.length > 0) {
        postData.ImageLinks.forEach((imageUrl) => {
            const imageElement = document.createElement("img");
            imageElement.src = imageUrl;
            imageElement.classList.add("media");
            postDiv.appendChild(imageElement);
        });
    }

    if (postData.VideoLinks && postData.VideoLinks.length > 0) {
        postData.VideoLinks.forEach((videoUrl) => {
            const videoElement = document.createElement("video");
            videoElement.src = videoUrl;
            videoElement.controls = true;
            videoElement.classList.add("media");
            postDiv.appendChild(videoElement);
        });
    }

    combinedPostsDiv.appendChild(postDiv);
}

// Function to format time
function formatTime(timestamp) {
    if (!timestamp) {
        return "Timestamp not available";
    }
    const date = timestamp.toDate(); // Convert Firestore timestamp to JavaScript Date object
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
}
