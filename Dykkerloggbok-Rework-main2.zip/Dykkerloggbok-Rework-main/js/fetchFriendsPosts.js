// Function to fetch and display friends' posts
function fetchFriendsPosts() {
    const user = auth.currentUser;
    const userId = user.uid;

    console.log("Current User ID:", userId); // Log current user ID

    // Reference to the current user's document
    const userRef = firestore.collection("users").doc(userId);

    // Listen for changes to the Friends array
    userRef.onSnapshot((doc) => {
        const friends = doc.data().Friends || [];

        console.log("Friends Array:", friends); // Log friends array

        // Clear previous friends' posts
        const friendsPostsList = document.getElementById("friendsPostsList");
        friendsPostsList.innerHTML = "";

        // Check if there are friends
        if (friends.length === 0) {
            console.log("No friends found.");
            return;
        }

        // Iterate over each friend
        friends.forEach((friendId) => {
            console.log("Friend ID:", friendId); // Log each friend

            // Reference to the friend's document
            const friendRef = firestore.collection("users").doc(friendId);

            // Retrieve friend's dives
            friendRef.collection("Dives").get()
                .then((querySnapshot) => {
                    // Get friend's data
                    friendRef.get()
                        .then((friendDoc) => {
                            const friendData = friendDoc.data();
                            const friendUsername = friendData.username;

                            // Display friend's username
                            const friendHeader = document.createElement("h3");
                            friendHeader.textContent = `${friendUsername}'s Posts`;
                            friendsPostsList.appendChild(friendHeader);

                            // Iterate over each dive
                            querySnapshot.forEach((doc) => {
                                const diveData = doc.data();

                                // Create a list item
                                const diveItem = document.createElement("li");

                                // Create an anchor element
                                const diveLink = document.createElement("a");
                                diveLink.textContent = `Username: ${friendUsername}, Date: ${diveData.Date}, Location: ${diveData.DiveLocation}`;

                                // Set the href attribute with the Dive ID as a query parameter
                                diveLink.href = `log.html?diveId=${doc.id}`;

                                // Append the anchor element to the list item
                                diveItem.appendChild(diveLink);

                                // Append the list item to the unordered list
                                friendsPostsList.appendChild(diveItem);
                            });
                        })
                        .catch((error) => {
                            console.error("Error fetching friend data:", error);
                        });
                })
                .catch((error) => {
                    console.error("Error fetching friend's dives:", error);
                });
        });
    });
}