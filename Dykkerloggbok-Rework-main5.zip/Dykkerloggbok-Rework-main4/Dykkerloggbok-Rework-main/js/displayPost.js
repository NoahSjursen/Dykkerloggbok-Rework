// displayPost.js

function displayPost(postData, type) {
    const combinedPostsDiv = document.getElementById("combinedPostsList");
    const postDiv = document.createElement("div");
    postDiv.classList.add("post");

    // Display username and visibility flag
    const usernameElement = document.createElement("div");
    usernameElement.classList.add("username");
    usernameElement.textContent = `${postData.DiverName} (${postData.Visibility})`; // Displaying username and visibility
    postDiv.appendChild(usernameElement);

    // Display time posted
    const timeElement = document.createElement("div");
    timeElement.classList.add("time");
    timeElement.textContent = formatTime(postData.Date); // Using Date field as the timestamp
    postDiv.appendChild(timeElement);

    // Display main text content
    const mainTextElement = document.createElement("div");
    mainTextElement.classList.add("main-text");
    mainTextElement.textContent = postData.MainTextContent;
    postDiv.appendChild(mainTextElement);

    // Additional information
    const additionalInfoDiv = document.createElement("div");
    additionalInfoDiv.classList.add("additional-info");
    additionalInfoDiv.innerHTML = `
        <p><strong>Observations:</strong> ${postData.Observations || '-'}</p>
        <p><strong>Incidents:</strong> ${postData.Incidents || '-'}</p>
        <p><strong>Diver Certifications:</strong> ${postData.DiverCertifications || '-'}</p>
        <p><strong>Dive Location:</strong> ${postData.DiveLocation || '-'}</p>
        <p><strong>Diver Buddies Name:</strong> ${postData.DiverBuddiesName || '-'}</p>
    `;
    postDiv.appendChild(additionalInfoDiv);

    // Create Swiper container for media content
    const swiperContainer = document.createElement("div");
    swiperContainer.classList.add("swiper-container");

    const swiperWrapper = document.createElement("div");
    swiperWrapper.classList.add("swiper-wrapper");

    // Display media content
    if (postData.MediaLinks && postData.MediaLinks.length > 0) {
        postData.MediaLinks.forEach((mediaUrl) => {
            const swiperSlide = document.createElement("div");
            swiperSlide.classList.add("swiper-slide");

            const mediaType = getMediaType(mediaUrl); // Function to determine media type (image or video)
            if (mediaType === 'image') {
                const imageElement = document.createElement("img");
                imageElement.src = mediaUrl;
                imageElement.classList.add("media");
                swiperSlide.appendChild(imageElement);
            } else if (mediaType === 'video') {
                const videoElement = document.createElement("video");
                videoElement.src = mediaUrl;
                videoElement.controls = true;
                videoElement.classList.add("media");
                swiperSlide.appendChild(videoElement);
            }

            swiperWrapper.appendChild(swiperSlide);
        });
    }

    swiperContainer.appendChild(swiperWrapper);
    postDiv.appendChild(swiperContainer);

    combinedPostsDiv.appendChild(postDiv);

    // Initialize Swiper
    new Swiper('.swiper-container', {
        // Optional parameters
        direction: 'horizontal',
        loop: true,

        // If you need pagination
        pagination: {
            el: '.swiper-pagination',
        },

        // Navigation arrows
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },

        // And if we need scrollbar
        scrollbar: {
            el: '.swiper-scrollbar',
        },
    });
}

// Function to format time
function formatTime(timestamp) {
    if (!timestamp) {
        return "Timestamp not available";
    }
    const date = timestamp.toDate(); // Convert Firestore timestamp to JavaScript Date object
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
}

// Function to determine media type based on URL
function getMediaType(url) {
    const extension = url.split('.').pop().toLowerCase();
    if (extension === 'mp4' || extension === 'webm' || extension === 'ogg') {
        return 'video';
    } else {
        return 'image';
    }
}
