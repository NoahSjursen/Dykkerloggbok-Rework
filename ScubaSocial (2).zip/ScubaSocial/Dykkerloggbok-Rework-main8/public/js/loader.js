// JavaScript to control the loader
document.addEventListener("DOMContentLoaded", function() {
    var loaderShown = false;

    // Show loader when navigating between pages
    window.addEventListener("beforeunload", function() {
        document.querySelector(".loader").style.display = "block";
        loaderShown = true;
    });
    
    // Hide loader when page is fully loaded, but only if it has been shown for at least 700ms
    window.addEventListener("load", function() {
        setTimeout(function() {
            if (!loaderShown) {
                // Ensure the loader is shown for at least 700ms
                setTimeout(function() {
                    document.querySelector(".loader").style.display = "none";
                }, 700);
            } else {
                document.querySelector(".loader").style.display = "none";
            }
        }, 460); // Wait at least 700ms before hiding the loader
    });
});
