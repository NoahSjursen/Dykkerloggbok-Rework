// displayPost.js

// displayPost.js

// displayPost.js

function displayPost(postData, type) {
    const combinedPostsDiv = document.getElementById("combinedPostsList");

    // Create the post div
    const postDiv = document.createElement("div");
    postDiv.classList.add("post");

    // Display username and visibility flag
    const usernameElement = document.createElement("div");
    usernameElement.classList.add("username");
    usernameElement.textContent = `${postData.DiverName} (${postData.Visibility})`; // Displaying username and visibility
    postDiv.appendChild(usernameElement);

    // Display time posted
    const timeElement = document.createElement("div");
    timeElement.classList.add("time");
    timeElement.textContent = formatTime(postData.Date); // Using Date field as the timestamp
    postDiv.appendChild(timeElement);

    // Display main text content
    const mainTextElement = document.createElement("div");
    mainTextElement.classList.add("main-text");
    mainTextElement.textContent = postData.MainTextContent;
    postDiv.appendChild(mainTextElement);

    // Additional information
    const additionalInfoDiv = document.createElement("div");
    additionalInfoDiv.classList.add("additional-info");
    additionalInfoDiv.innerHTML = `
        <p><strong>Observations:</strong> ${postData.Observations || '-'}</p>
        <p><strong>Incidents:</strong> ${postData.Incidents || '-'}</p>
        <p><strong>Diver Certifications:</strong> ${postData.DiverCertifications || '-'}</p>
        <p><strong>Dive Location:</strong> ${postData.DiveLocation || '-'}</p>
        <p><strong>Diver Buddies Name:</strong> ${postData.DiverBuddiesName || '-'}</p>
    `;
    postDiv.appendChild(additionalInfoDiv);

    // Create container for media content
    const mediaContainer = document.createElement("div");
    mediaContainer.classList.add("media-container");

    // Display media content
    if (postData.MediaLinks && postData.MediaLinks.length > 0) {
        postData.MediaLinks.forEach((mediaUrl) => {
            const mediaType = getMediaType(mediaUrl); // Function to determine media type (image or video)

            if (mediaType === 'image') {
                const imageElement = document.createElement("img");
                imageElement.src = mediaUrl;
                imageElement.classList.add("media");
                mediaContainer.appendChild(imageElement);
            } else if (mediaType === 'video') {
                const videoElement = document.createElement("video");
                videoElement.src = mediaUrl;
                videoElement.controls = true;
                videoElement.classList.add("media");
                mediaContainer.appendChild(videoElement);
            }
        });
    }

    postDiv.appendChild(mediaContainer);

    // Append the post div to the container
    combinedPostsDiv.appendChild(postDiv);
}


// Function to format time
function formatTime(timestamp) {
    if (!timestamp) {
        return "Timestamp not available";
    }
    const date = timestamp.toDate(); // Convert Firestore timestamp to JavaScript Date object
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
}

function getMediaType(url) {
    const lowerCaseUrl = url.toLowerCase();
    if (lowerCaseUrl.includes('.mp4') || lowerCaseUrl.includes('.webm') || lowerCaseUrl.includes('.ogg')) {
        return 'video';
    } else if (lowerCaseUrl.includes('videos/')) {
        return 'video';
    } else {
        return 'image';
    }
}


