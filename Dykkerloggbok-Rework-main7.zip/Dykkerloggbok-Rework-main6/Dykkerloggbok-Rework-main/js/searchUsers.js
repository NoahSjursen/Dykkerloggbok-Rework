// Function to search for users by username
function searchUsersByUsername() {
    const username = document.getElementById("searchUsername").value.trim();
    const searchResultsList = document.getElementById("searchResults");
    searchResultsList.innerHTML = "";

    // Query Firestore to find users with matching usernames
    firebase.firestore().collection("users").get()
        .then((querySnapshot) => {
            querySnapshot.forEach((userDoc) => {
                const userData = userDoc.data();
                const userId = userDoc.id;
                const userUsername = userData.username; // Retrieve username directly from the UID document

                if (userUsername === username) {
                    // Create a list item for the matching user
                    const userItem = document.createElement("li");
                    userItem.textContent = `@${userUsername}`;
                    
                    // Create a button to add the user as a friend
                    const addButton = document.createElement("button");
                    addButton.textContent = "Add Friend";
                    addButton.onclick = function() {
                        addFriend(userId);
                    };
                    userItem.appendChild(addButton);
                    
                    // Append the list item to the search results list
                    searchResultsList.appendChild(userItem);
                }
            });

            // Display a message if no results found
            if (searchResultsList.children.length === 0) {
                const noResultsItem = document.createElement("li");
                noResultsItem.textContent = "No users found with that username.";
                searchResultsList.appendChild(noResultsItem);
            }
        })
        .catch((error) => {
            console.error("Error searching for users:", error);
        });
}
