// fetchPersonalPosts.js

// Function to fetch dive posts from Firestore
async function fetchDivePosts() {
    try {
        const user = firebase.auth().currentUser;
        if (user) {
            const userId = user.uid;
            const divesSnapshot = await firebase.firestore()
                .collection("users")
                .doc(userId)
                .collection("Dives")
                .get();
            
            const divePosts = [];
            divesSnapshot.forEach((doc) => {
                divePosts.push(doc.data());
            });
            
            return divePosts;
        } else {
            console.log("No user signed in.");
            return [];
        }
    } catch (error) {
        console.error("Error fetching dives:", error);
        return [];
    }
}

// Function to display dive posts in the personal-posts-container
async function displayDivePosts() {
    const personalPostsContainer = document.getElementById("personalPostsContainer");
    personalPostsContainer.innerHTML = ""; // Clear previous content
    
    const divePosts = await fetchDivePosts();
    
    // Display dive posts
    divePosts.forEach((diveData) => {
        displayDivePost(diveData);
    });
}

// Function to display a single dive post
function displayDivePost(diveData) {
    const postContainer = document.getElementById("personalPostsContainer");
    const postDiv = document.createElement("div");
    postDiv.classList.add("post");

    // Create and append elements to the postDiv based on diveData
    // For example:
    postDiv.innerHTML = `
        <img class="profile-photo" src="${diveData.profilePhoto || "default-profile-photo.jpg"}" alt="Profile Picture">
        <div class="username">@${diveData.DiverName} (${diveData.Visibility})</div>
        <div class="time">${formatTime(diveData.Date)}</div>
        <div class="main-text">${diveData.MainTextContent}</div>
        <div class="additional-info">
            <p><strong>Observations:</strong> ${diveData.Observations || '-'}</p>
            <p><strong>Incidents:</strong> ${diveData.Incidents || '-'}</p>
            <p><strong>Diver Certifications:</strong> ${diveData.DiverCertifications || '-'}</p>
            <p><strong>Dive Location:</strong> ${diveData.DiveLocation || '-'}</p>
            <p><strong>Diver Buddies Name:</strong> ${diveData.DiverBuddiesName || '-'}</p>
        </div>
        <!-- Add media content here -->
    `;
    
    postContainer.appendChild(postDiv);
}

// Function to format time
function formatTime(timestamp) {
    if (!timestamp) {
        return "Timestamp not available";
    }
    const date = timestamp.toDate(); // Convert Firestore timestamp to JavaScript Date object
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
}


// Call the displayDivePosts function when the user is signed in
firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        displayDivePosts();
    } else {
        console.log("No user signed in.");
    }
});
