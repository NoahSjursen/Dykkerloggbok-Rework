// Function to fetch and display public posts
function fetchPublicPosts() {
    // Reference to the "Public_Posts" collection
    const publicPostsRef = firestore.collection("Public_Posts");

    // Clear previous public posts
    const publicPostsList = document.getElementById("publicPostsList");
    publicPostsList.innerHTML = "";

    // Retrieve public posts from Firestore
    publicPostsRef.get()
        .then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                const postData = doc.data();

                // Create a list item for each public post
                const postListItem = document.createElement("li");
                postListItem.classList.add("post");

                // Add content to the post list item
                postListItem.innerHTML = `
                    <h3>Date: ${postData.Date}</h3>
                    <p>Dive Location: ${postData.DiveLocation}</p>
                    <p>Main Text Content: ${postData.MainTextContent}</p>
                    <p>Posted By: ${postData.Username}</p>
                `;

                // Append the post list item to the public posts list
                publicPostsList.appendChild(postListItem);
            });
        })
        .catch((error) => {
            console.error("Error fetching public posts:", error);
        });
}